// =============================================================
// PATRA — /journals browse + search page.
//   Cover grid · search by name · sort (IF / CAS / A–Z / cited)
//   · collapsible filter rail (desktop) / sheet (mobile + drawer
//   tweak) · faceted counts · page-number pagination · empty
//   result. URL query (#/journals?…) stays in sync for sharing.
//
// Loaded after journals-data.jsx + detail-shared.jsx, so
// JOURNAL_CATALOG, navigate, Icon*, PatraMark are global.
// =============================================================

const IconFilter = (p) => <Icon {...p}><path d="M3 5h18" /><path d="M7 12h10" /><path d="M10 19h4" /></Icon>;

const CAT = () => (typeof JOURNAL_CATALOG !== "undefined" ? JOURNAL_CATALOG : []);
const PAGE_SIZE = 12;

const SORTS = [
  { id: "if",    label: "影响因子", ord: "↓" },
  { id: "cas",   label: "中科院分区" },
  { id: "az",    label: "刊名 A–Z" },
  { id: "cited", label: "被引总数", ord: "↓" },
];

const FACET_GROUPS = ["subject", "jcr", "cas", "casTop", "oa", "doaj", "country"];

// ── precomputed "present" option lists (catalog order) ───────
function presentOptions() {
  const cat = CAT();
  const subjOrder = (typeof SUBJECTS !== "undefined" ? SUBJECTS : []);
  const subjSet = new Set(cat.map(j => j.subject));
  const subjects = subjOrder.filter(s => subjSet.has(s.zh));
  const jcrSet = new Set(cat.map(j => j.jcrQuartile));
  const jcr = (typeof JCR_QUARTILES !== "undefined" ? JCR_QUARTILES : []).filter(q => jcrSet.has(q));
  const casSet = new Set(cat.map(j => j.casQuartile));
  const cas = (typeof CAS_ZONES !== "undefined" ? CAS_ZONES : []).filter(z => casSet.has(z));
  const ctrOrder = (typeof COUNTRIES !== "undefined" ? COUNTRIES : []);
  const ctrSet = new Set(cat.map(j => j.country));
  const countries = ctrOrder.filter(c => ctrSet.has(c.code));
  return { subjects, jcr, cas, countries };
}

// ── url query <-> filter state ──────────────────────────────
function parseBrowseQuery() {
  const hash = window.location.hash || "";
  const qi = hash.indexOf("?");
  const sp = new URLSearchParams(qi >= 0 ? hash.slice(qi + 1) : "");
  const arr = (k) => { const v = sp.get(k); return v ? v.split(",").filter(Boolean) : []; };
  const sort = sp.get("sort");
  return {
    q: sp.get("q") || "",
    sort: SORTS.some(s => s.id === sort) ? sort : "if",
    page: Math.max(1, parseInt(sp.get("page") || "1", 10) || 1),
    subject: arr("subject"),
    jcr: arr("jcr"),
    cas: arr("cas"),
    casTop: sp.get("casTop") === "1",
    oa: sp.get("oa") === "1",
    doaj: sp.get("doaj") === "1",
    country: arr("country"),
  };
}
function writeBrowseQuery(f) {
  const sp = new URLSearchParams();
  if (f.q) sp.set("q", f.q);
  if (f.sort && f.sort !== "if") sp.set("sort", f.sort);
  if (f.page > 1) sp.set("page", String(f.page));
  if (f.subject.length) sp.set("subject", f.subject.join(","));
  if (f.jcr.length) sp.set("jcr", f.jcr.join(","));
  if (f.cas.length) sp.set("cas", f.cas.join(","));
  if (f.casTop) sp.set("casTop", "1");
  if (f.oa) sp.set("oa", "1");
  if (f.doaj) sp.set("doaj", "1");
  if (f.country.length) sp.set("country", f.country.join(","));
  const qs = sp.toString();
  try { history.replaceState(null, "", qs ? `#/journals?${qs}` : "#/journals"); } catch (e) {}
}

// ── predicates ──────────────────────────────────────────────
function matchQuery(j, q) {
  if (!q) return true;
  const s = q.trim().toLowerCase();
  if (!s) return true;
  return j.name.toLowerCase().includes(s)
      || j.abbr.toLowerCase().includes(s)
      || (j.cover || "").toLowerCase().replace(/\n/g, " ").includes(s);
}
function passGroup(j, f, g) {
  switch (g) {
    case "subject": return !f.subject.length || f.subject.includes(j.subject);
    case "jcr":     return !f.jcr.length || f.jcr.includes(j.jcrQuartile);
    case "cas":     return !f.cas.length || f.cas.includes(j.casQuartile);
    case "casTop":  return !f.casTop || j.casIsTop;
    case "oa":      return !f.oa || j.isOpenAccess;
    case "doaj":    return !f.doaj || j.isInDoaj;
    case "country": return !f.country.length || f.country.includes(j.country);
    default:        return true;
  }
}
function matchAll(j, f, except) {
  return matchQuery(j, f.q) && FACET_GROUPS.every(g => g === except || passGroup(j, f, g));
}

const CAS_RANK = { "1区": 1, "2区": 2, "3区": 3, "4区": 4 };
function sortJournals(list, sort) {
  const a = [...list];
  if (sort === "if")    a.sort((x, y) => y.impactFactor - x.impactFactor);
  else if (sort === "cited") a.sort((x, y) => y.citedTotal - x.citedTotal);
  else if (sort === "az") a.sort((x, y) => x.name.localeCompare(y.name, "en"));
  else if (sort === "cas") a.sort((x, y) =>
    (CAS_RANK[x.casQuartile] - CAS_RANK[y.casQuartile])
    || (Number(y.casIsTop) - Number(x.casIsTop))
    || (y.impactFactor - x.impactFactor));
  return a;
}

function pageWindow(cur, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const out = [1];
  const lo = Math.max(2, cur - 1), hi = Math.min(total - 1, cur + 1);
  if (lo > 2) out.push("…");
  for (let p = lo; p <= hi; p++) out.push(p);
  if (hi < total - 1) out.push("…");
  out.push(total);
  return out;
}

// ── small reusable rows ─────────────────────────────────────
function CheckRow({ checked, onChange, label, en, count }) {
  return (
    <label className={`fopt ${count === 0 && !checked ? "is-zero" : ""}`}>
      <input type="checkbox" checked={checked} onChange={onChange} />
      <span className="box"><IconCheck size={12} /></span>
      <span className="fname">{label}{en && <span className="fen">{en}</span>}</span>
      <span className="fcnt">{count}</span>
    </label>
  );
}
function ToggleRow({ checked, onChange, label, leaf, count }) {
  return (
    <label className="ftoggle-row">
      <span className="fname">{leaf && <span className="leaf"><IconLeaf size={13} /></span>}{label}</span>
      {count != null && <span className="fcnt">{count}</span>}
      <input type="checkbox" checked={checked} onChange={onChange} />
      <span className="fswitch" />
    </label>
  );
}
function Facet({ title, selCount, defaultOpen = true, children }) {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div className="facet" data-open={open}>
      <button className="facet-head" type="button" aria-expanded={open} onClick={() => setOpen(o => !o)}>
        <span className="chev"><IconChevR size={15} /></span>
        <span className="facet-t">{title}</span>
        {selCount > 0 && <span className="fsel">{selCount}</span>}
      </button>
      {open && <div className="facet-body" role="group" aria-label={title}>{children}</div>}
    </div>
  );
}

// ── filter controls (shared between rail + sheet) ───────────
function FilterControls({ f, counts, opts, toggleArr, toggleBool }) {
  return (
    <>
      <Facet title="学科领域" selCount={f.subject.length}>
        {opts.subjects.map(s => (
          <CheckRow key={s.zh} label={s.zh} en={s.en} count={counts.subject.get(s.zh) || 0}
                    checked={f.subject.includes(s.zh)} onChange={() => toggleArr("subject", s.zh)} />
        ))}
      </Facet>

      <Facet title="JCR 分区" selCount={f.jcr.length}>
        {opts.jcr.map(q => (
          <CheckRow key={q} label={q} count={counts.jcr.get(q) || 0}
                    checked={f.jcr.includes(q)} onChange={() => toggleArr("jcr", q)} />
        ))}
      </Facet>

      <Facet title="中科院分区" selCount={f.cas.length + (f.casTop ? 1 : 0)}>
        {opts.cas.map(z => (
          <CheckRow key={z} label={z} count={counts.cas.get(z) || 0}
                    checked={f.cas.includes(z)} onChange={() => toggleArr("cas", z)} />
        ))}
        <div style={{ borderTop: "1px solid var(--border-subtle)", margin: "6px 0 2px", paddingTop: 4 }}>
          <ToggleRow label="仅 Top 期刊" checked={f.casTop} count={counts.casTop}
                     onChange={() => toggleBool("casTop")} />
        </div>
      </Facet>

      <Facet title="开放获取" selCount={(f.oa ? 1 : 0) + (f.doaj ? 1 : 0)}>
        <div className="ftoggle">
          <ToggleRow label="仅开放获取" leaf checked={f.oa} count={counts.oa} onChange={() => toggleBool("oa")} />
          <ToggleRow label="收录于 DOAJ" checked={f.doaj} count={counts.doaj} onChange={() => toggleBool("doaj")} />
        </div>
      </Facet>

      <Facet title="国家 / 地区" selCount={f.country.length}>
        {opts.countries.map(c => (
          <CheckRow key={c.code} label={c.zh} en={c.code} count={counts.country.get(c.code) || 0}
                    checked={f.country.includes(c.code)} onChange={() => toggleArr("country", c.code)} />
        ))}
      </Facet>
    </>
  );
}

// ── cover card ──────────────────────────────────────────────
function JournalBrowseCard({ j }) {
  const { bg, ink } = j.coverStyle || {};
  return (
    <a className="jbcard" href={`#/journals/${j.id}`}
       onClick={(e) => { e.preventDefault(); navigate(`#/journals/${j.id}`); }}>
      <div className="jbcover" style={{ background: bg, color: ink }}>
        <div className="jbcover-band">{j.casMajor} · {j.country}</div>
        <div className="jbcover-word">{j.cover}</div>
        {j.isOpenAccess && <div className="jbcover-oa"><IconLeaf size={10} /> open access</div>}
      </div>
      <div className="jbmeta">
        <div className="jbmeta-name">{j.name}</div>
        <div className="jbmeta-abbr">{j.abbr}</div>
        <div className="jbmeta-stats">
          <div className="jb-if">
            <span className="num">{j.impactFactor.toFixed(1)}</span>
            <span className="lbl">影响因子</span>
          </div>
          <div className="jb-zones">
            <span className={`jb-q ${j.jcrQuartile === "Q1" ? "jcr-q1" : ""}`}>JCR {j.jcrQuartile}</span>
            <span className="jb-q cas">中科院 {j.casQuartile}{j.casIsTop && <span className="top">TOP</span>}</span>
          </div>
        </div>
      </div>
    </a>
  );
}

// ── empty result ────────────────────────────────────────────
function EmptyResult({ q, hasFilters, onReset }) {
  return (
    <div className="jb-empty">
      <div className="mark"><PatraMark height={76} /></div>
      <span className="jb-empty-code"><span className="dot" /> 0 results · 无命中</span>
      <h2 className="jb-empty-title">
        {q ? <>未找到匹配 <q>{q}</q> 的期刊</> : "没有符合条件的期刊"}
      </h2>
      <p className="jb-empty-body">
        {q
          ? "换个刊名或缩写试试，或放宽筛选条件。本页检索的是期刊本身 —— 若要检索文献，请回首页。"
          : "当前筛选组合下没有期刊。试着移除一两个条件，或清除全部筛选重新开始。"}
      </p>
      <div className="jb-empty-actions">
        {hasFilters && <button className="btn btn-primary" type="button" onClick={onReset}>清除全部筛选</button>}
        <button className="btn btn-sec" type="button" onClick={() => navigate("#/")}>返回首页</button>
      </div>
    </div>
  );
}

// ── main page ───────────────────────────────────────────────
function JournalsBrowse() {
  styleTagOnce("journals-browse-runtime", ""); // no-op guard for symmetry
  const ctx = (typeof useTweakCtx === "function" ? useTweakCtx() : {}) || {};
  const filterMount = ctx.filterMount || "rail";

  const [f, setF] = React.useState(parseBrowseQuery);
  const [sheetOpen, setSheetOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [isNarrow, setIsNarrow] = React.useState(
    typeof window !== "undefined" && window.matchMedia("(max-width: 980px)").matches);

  React.useEffect(() => {
    const mq = window.matchMedia("(max-width: 980px)");
    const on = () => setIsNarrow(mq.matches);
    mq.addEventListener ? mq.addEventListener("change", on) : mq.addListener(on);
    return () => { mq.removeEventListener ? mq.removeEventListener("change", on) : mq.removeListener(on); };
  }, []);

  React.useEffect(() => { writeBrowseQuery(f); }, [f]);
  React.useEffect(() => {
    document.body.style.overflow = sheetOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [sheetOpen]);

  const useSheet = filterMount === "drawer" || isNarrow;
  const showRail = !useSheet;

  const opts = React.useMemo(presentOptions, []);

  // state mutators (any facet/query/sort change resets to page 1)
  const patch = (p) => setF(prev => ({ ...prev, ...p, page: 1 }));
  const toggleArr = (group, value) => setF(prev => {
    const cur = prev[group];
    const next = cur.includes(value) ? cur.filter(x => x !== value) : [...cur, value];
    return { ...prev, [group]: next, page: 1 };
  });
  const toggleBool = (key) => setF(prev => ({ ...prev, [key]: !prev[key], page: 1 }));
  const clearAll = () => setF(prev => ({
    ...prev, subject: [], jcr: [], cas: [], casTop: false, oa: false, doaj: false, country: [], page: 1,
  }));
  const resetAll = () => setF(prev => ({
    ...prev, q: "", subject: [], jcr: [], cas: [], casTop: false, oa: false, doaj: false, country: [], page: 1,
  }));
  const goPage = (n) => {
    setF(prev => ({ ...prev, page: n }));
    setLoading(true);
    setTimeout(() => setLoading(false), 280);
    const bar = document.querySelector(".jb-bar");
    if (bar) window.scrollTo({ top: bar.getBoundingClientRect().top + window.scrollY - 8, behavior: "smooth" });
  };

  // results + facet counts
  const cat = CAT();
  const results = React.useMemo(() => sortJournals(cat.filter(j => matchAll(j, f, null)), f.sort), [cat, f]);
  const counts = React.useMemo(() => {
    const cb = (group, keyFn) => (typeof countBy === "function"
      ? countBy(cat.filter(j => matchAll(j, f, group)), keyFn)
      : new Map());
    const flag = (group, fn) => cat.filter(j => matchAll(j, f, group) && fn(j)).length;
    return {
      subject: cb("subject", j => j.subject),
      jcr: cb("jcr", j => j.jcrQuartile),
      cas: cb("cas", j => j.casQuartile),
      country: cb("country", j => j.country),
      casTop: flag("casTop", j => j.casIsTop),
      oa: flag("oa", j => j.isOpenAccess),
      doaj: flag("doaj", j => j.isInDoaj),
    };
  }, [cat, f]);

  const total = results.length;
  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const page = Math.min(f.page, pageCount);
  const start = (page - 1) * PAGE_SIZE;
  const pageItems = results.slice(start, start + PAGE_SIZE);

  const activeCount = f.subject.length + f.jcr.length + f.cas.length + f.country.length
    + (f.casTop ? 1 : 0) + (f.oa ? 1 : 0) + (f.doaj ? 1 : 0);
  const hasFilters = activeCount > 0;

  // active-filter chips
  const chips = [];
  const subjEn = (typeof SUBJECT_EN !== "undefined" ? SUBJECT_EN : {});
  const ctrZh = (typeof COUNTRY_ZH !== "undefined" ? COUNTRY_ZH : {});
  f.subject.forEach(v => chips.push({ k: "学科", label: v, rm: () => toggleArr("subject", v) }));
  f.jcr.forEach(v => chips.push({ k: "JCR", label: v, rm: () => toggleArr("jcr", v) }));
  f.cas.forEach(v => chips.push({ k: "中科院", label: v, rm: () => toggleArr("cas", v) }));
  if (f.casTop) chips.push({ k: "中科院", label: "Top", rm: () => toggleBool("casTop") });
  if (f.oa) chips.push({ k: "OA", label: "开放获取", rm: () => toggleBool("oa") });
  if (f.doaj) chips.push({ k: "OA", label: "DOAJ", rm: () => toggleBool("doaj") });
  f.country.forEach(v => chips.push({ k: "地区", label: ctrZh[v] || v, rm: () => toggleArr("country", v) }));

  const onFilterBtn = () => setSheetOpen(true);

  return (
    <div className="jb" data-screen-label="Journals browse">
      {/* breadcrumb bar */}
      <div className="dp-bar">
        <div className="container dp-bar-row">
          <nav className="crumbs" aria-label="面包屑">
            <a href="#/" onClick={(e) => { e.preventDefault(); navigate("#/"); }}>Patra</a>
            <span className="sep">/</span>
            <span className="here">期刊浏览</span>
          </nav>
          <span className="jb-snap" style={{ fontFamily: "var(--font-mono)", fontSize: "10.5px", color: "var(--fg-4)", textTransform: "uppercase", letterSpacing: "0.06em", whiteSpace: "nowrap" }}>
            索引快照 17:42
          </span>
        </div>
      </div>

      <div className="container">
        {/* head */}
        <header className="jb-head">
          <span className="eyebrow"><span className="leaf"><PatraMark height={16} /></span> 按期刊浏览</span>
          <h1 className="jb-head-title">浏览全部<em>期刊</em></h1>
          <p className="jb-head-sub">
            Patra 追踪的同行评审期刊 —— 按刊名检索，按影响因子、中科院分区或被引排序，按学科与分区收敛。点开任一刊进入详情。
          </p>
        </header>

        {/* search / sort / count bar */}
        <div className="jb-bar">
          <div className="jb-bar-row">
            <form className="jb-searchform" onSubmit={(e) => { e.preventDefault(); e.currentTarget.querySelector("input").blur(); }}>
              <div className="jb-search">
                <span className="ic"><IconSearch size={18} /></span>
                <input
                  type="text" placeholder="按刊名 / 缩写检索期刊"
                  value={f.q} onChange={(e) => patch({ q: e.target.value })}
                  autoComplete="off" spellCheck="false" aria-label="按刊名检索期刊"
                />
                {f.q && (
                  <button className="clear" type="button" aria-label="清除搜索" onClick={() => patch({ q: "" })}>
                    <IconX size={15} />
                  </button>
                )}
              </div>
              <button className="jb-search-go" type="submit"><span className="ic-go"><IconSearch size={15} /></span> 检索</button>
            </form>

            <div className="jb-sort">
              <span className="lbl">排序</span>
              <div className="jb-seg" role="group" aria-label="排序方式">
                {SORTS.map(s => (
                  <button key={s.id} type="button" className={f.sort === s.id ? "on" : ""}
                          aria-pressed={f.sort === s.id} onClick={() => patch({ sort: s.id })}>
                    {s.label}{s.ord && <span className="ord">{s.ord}</span>}
                  </button>
                ))}
              </div>
            </div>

            {useSheet && (
              <button className="jb-filter-btn" type="button"
                      onClick={onFilterBtn} aria-label="筛选">
                <IconFilter size={16} /> 筛选
                {activeCount > 0 && <span className="fcount">{activeCount}</span>}
              </button>
            )}
          </div>
        </div>

        {/* layout */}
        <div className="jb-layout" data-rail={showRail ? "open" : "closed"}>
          {showRail && (
            <aside className="jb-rail" aria-label="筛选">
              <div className="jb-rail-inner">
                <div className="jb-rail-head">
                  <span className="t"><IconFilter size={15} /> 筛选</span>
                  <button className="clr" type="button" onClick={clearAll} disabled={!hasFilters}>清除全部</button>
                </div>
                <FilterControls f={f} counts={counts} opts={opts} toggleArr={toggleArr} toggleBool={toggleBool} />
              </div>
            </aside>
          )}

          <div className="jb-results">
            <div className="jb-resulthead">
              <div className="jb-count">
                共 <b>{total.toLocaleString()}</b> 本期刊
                {f.q && <> · 匹配 <span className="q">“{f.q}”</span></>}
              </div>
              {(chips.length > 0) && (
                <div className="jb-active">
                  {chips.map((c, i) => (
                    <span className="jb-fchip" key={i}>
                      <span className="k">{c.k}</span>{c.label}
                      <button type="button" aria-label={`移除 ${c.label}`} onClick={c.rm}><IconX size={11} /></button>
                    </span>
                  ))}
                  <button className="jb-clearall" type="button" onClick={clearAll}>清除全部</button>
                </div>
              )}
            </div>

            {total === 0 ? (
              <EmptyResult q={f.q} hasFilters={hasFilters || !!f.q} onReset={resetAll} />
            ) : (
              <>
                {loading && <div className="jb-loading-bar" aria-hidden="true" />}
                <div className={`jb-grid ${loading ? "is-loading" : ""}`} role="list">
                  {pageItems.map(j => (
                    <div role="listitem" key={j.id}><JournalBrowseCard j={j} /></div>
                  ))}
                </div>

                {pageCount > 1 && (
                  <nav className="jb-pager" aria-label="分页">
                    <div className="jb-pager-info">
                      第 {start + 1}–{Math.min(start + PAGE_SIZE, total)} 本 · 共 {total} 本
                    </div>
                    <div className="jb-pages">
                      <button className="jb-page nav" type="button" disabled={page <= 1}
                              onClick={() => goPage(page - 1)} aria-label="上一页">‹</button>
                      {pageWindow(page, pageCount).map((p, i) =>
                        p === "…"
                          ? <span className="jb-page ellip" key={`e${i}`}>…</span>
                          : <button key={p} type="button" className={`jb-page ${p === page ? "on" : ""}`}
                                    aria-current={p === page ? "page" : undefined} onClick={() => goPage(p)}>{p}</button>
                      )}
                      <button className="jb-page nav" type="button" disabled={page >= pageCount}
                              onClick={() => goPage(page + 1)} aria-label="下一页">›</button>
                    </div>
                  </nav>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* filter sheet (mobile + drawer mode) */}
      {sheetOpen && (
        <>
          <div className="jb-scrim" onClick={() => setSheetOpen(false)} />
          <div className="jb-sheet" role="dialog" aria-label="筛选" aria-modal="true">
            <div className="jb-sheet-head">
              <span className="t"><IconFilter size={17} /> 筛选{activeCount > 0 && <span className="fcount" style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--clay-700)" }}>· {activeCount}</span>}</span>
              <button className="x" type="button" aria-label="关闭" onClick={() => setSheetOpen(false)}><IconX size={18} /></button>
            </div>
            <div className="jb-sheet-body">
              <FilterControls f={f} counts={counts} opts={opts} toggleArr={toggleArr} toggleBool={toggleBool} />
            </div>
            <div className="jb-sheet-foot">
              <button className="btn btn-sec" type="button" onClick={clearAll} disabled={!hasFilters}>清除</button>
              <button className="btn btn-primary" type="button" onClick={() => setSheetOpen(false)}>
                查看 {total} 本结果
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

Object.assign(window, { JournalsBrowse });
