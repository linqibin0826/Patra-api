// =============================================================
// PATRA — global status screens (reusable across the site).
//   NotFoundState  → 404 (bad URL / missing id)
//   ErrorState     → render/fetch failure fallback
// Same warm editorial language as the homepage. Responsive
// (desktop + mobile) via .status. Librarian voice, no stack
// traces exposed.
// =============================================================

function NotFoundState({ kind = "page", id }) {
  // kind: "journal" | "paper" | "page"  → tailor the one line.
  const line = {
    journal: "这本期刊不在 Patra 的索引里 —— 可能 ID 有误，或它尚未被收录。",
    paper: "这篇文献不在 Patra 的索引里 —— 可能 ID 有误，或它尚未被采集。",
    page: "这个地址在 Patra 里找不到对应内容。链接可能已失效，或从未存在。",
  }[kind];
  const path = kind === "journal" ? `/journals/${id || "—"}`
             : kind === "paper" ? `/papers/${id || "—"}`
             : "not-found";

  return (
    <div className="status" data-screen-label="404 NotFound">
      <div className="status-inner">
        <div className="status-mark">
          <span className="leaf" aria-hidden="true"><PatraMark height={88} /></span>
          <span className="num">404</span>
        </div>
        <span className="status-code"><span className="dot" /> HTTP 404 · not found</span>
        <h1 className="status-title">没有这一页</h1>
        <p className="status-body">{line}</p>
        <div className="status-actions">
          <button className="btn btn-primary" type="button" onClick={() => navigate("#/")}>
            <IconHome size={15} /> 返回首页
          </button>
          <button className="btn btn-sec" type="button" onClick={() => { navigate("#/"); setTimeout(() => document.querySelector('#hero-input')?.focus(), 60); }}>
            <IconSearch size={15} /> 去检索
          </button>
        </div>
        <details className="status-detail">
          <summary><IconChevR size={13} /> 技术细节</summary>
          <div className="body">
            <div className="row"><span className="rk">requested</span><span>{path}</span></div>
            <div className="row"><span className="rk">status</span><span>404 · resource not found</span></div>
            <div className="row"><span className="rk">trace</span><span>req_8f2a·c41d·{(id || "0000").toString().slice(-4)}</span></div>
          </div>
        </details>
      </div>
    </div>
  );
}

function ErrorState({ onRetry, context = "取数", detail }) {
  const now = new Date();
  const ts = now.toISOString().replace("T", " ").slice(0, 19) + " UTC";
  return (
    <div className="status" data-screen-label="Error">
      <div className="status-inner">
        <div className="status-mark">
          <span className="leaf" aria-hidden="true" style={{ opacity: 0.85 }}><PatraMark height={88} /></span>
          <span className="num" style={{ color: "var(--rust-50)" }}>500</span>
        </div>
        <span className="status-code err"><span className="dot" /> 服务异常 · 兜底页</span>
        <h1 className="status-title">这一页没能加载出来</h1>
        <p className="status-body">
          {context}时出了点问题 —— 可能是上游来源短暂不可用，或一次性的网络抖动。这通常重试就能恢复。
        </p>
        <div className="status-actions">
          <button className="btn btn-primary" type="button" onClick={onRetry}>
            <IconRefresh size={15} /> 重试
          </button>
          <button className="btn btn-sec" type="button" onClick={() => navigate("#/")}>
            <IconHome size={15} /> 返回首页
          </button>
        </div>
        <details className="status-detail">
          <summary><IconAlert size={13} /> 错误信息</summary>
          <div className="body">
            <div className="row"><span className="rk">message</span><span>{detail || "Upstream returned 503 · service temporarily unavailable"}</span></div>
            <div className="row"><span className="rk">phase</span><span>{context}</span></div>
            <div className="row"><span className="rk">time</span><span>{ts}</span></div>
            <div className="row"><span className="rk">trace</span><span>req_3b90·a1f7·err</span></div>
          </div>
        </details>
      </div>
    </div>
  );
}

Object.assign(window, { NotFoundState, ErrorState });
