// =============================================================
// PATRA — detail-page shared primitives.
// Disclosure · EvidenceBadge · Metric · IdentifierChip ·
// RatingTable · TrendChart · AuthorList · AbstractBlock ·
// skeletons · StateSwitcher · navigate/copy helpers.
//
// Loaded after components.jsx, so window.Icon, IconChevR, etc.
// from the homepage are available as globals.
// =============================================================

// ---- routing + clipboard helpers ----------------------------
function navigate(to) {
  if (to.startsWith("#")) window.location.hash = to;
  else window.location.hash = "#" + to;
  window.scrollTo({ top: 0, behavior: "auto" });
}

function ensureToast() {
  let el = document.getElementById("patra-toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "patra-toast";
    el.className = "copy-toast";
    document.body.appendChild(el);
  }
  return el;
}
function showToast(msg) {
  const el = ensureToast();
  el.innerHTML = "";
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("show"), 1500);
}
async function copyText(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      document.execCommand("copy"); document.body.removeChild(ta);
    }
    return true;
  } catch (e) { return false; }
}

// ---- extra icons (homepage subset doesn't cover these) ------
const IconCopy   = (p) => <Icon {...p}><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></Icon>;
const IconCheck  = (p) => <Icon {...p}><path d="M5 12.5 10 17l9-10"/></Icon>;
const IconLink   = (p) => <Icon {...p}><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/></Icon>;
const IconRefresh= (p) => <Icon {...p}><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></Icon>;
const IconHome   = (p) => <Icon {...p}><path d="m3 11 9-8 9 8"/><path d="M5 9.5V21h14V9.5"/></Icon>;
const IconAlert  = (p) => <Icon {...p}><path d="M12 9v4.5"/><path d="M12 17h.01"/><path d="M10.3 4.3 2.6 18a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 4.3a2 2 0 0 0-3.4 0Z"/></Icon>;
const IconSparkle= (p) => <Icon {...p}><path d="M12 3v4M12 17v4M5 12H1M23 12h-4M6.3 6.3l2.4 2.4M15.3 15.3l2.4 2.4M17.7 6.3l-2.4 2.4M8.7 15.3l-2.4 2.4"/></Icon>;
const IconCal    = (p) => <Icon {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></Icon>;

// ---- Disclosure ---------------------------------------------
function DisclosureSection({ title, count, defaultOpen = false, children }) {
  const [open, setOpen] = React.useState(defaultOpen);
  const bodyId = React.useId();
  return (
    <section className="disc" data-open={open}>
      <button
        className="disc-head"
        type="button"
        aria-expanded={open}
        aria-controls={bodyId}
        onClick={() => setOpen(o => !o)}
      >
        <span className="chev"><IconChevR size={16} /></span>
        <span className="htitle">{title}</span>
        {count != null && <span className="hcount">{count}</span>}
      </button>
      {open && (
        <div className="disc-body" id={bodyId}>
          <div className="disc-body-inner">{children}</div>
        </div>
      )}
    </section>
  );
}

// ---- Evidence badge -----------------------------------------
function EvidenceBadge({ level, size = "md" }) {
  const info = EVIDENCE_LEVELS[level] || EVIDENCE_LEVELS.unknown;
  const tone = info.tone;
  const lit = info.tier >= 1 ? (6 - info.tier) : 0;
  const heights = [7, 10, 12, 14, 16];
  return (
    <span className={`ev tone-${tone}`} title={`证据等级 · ${info.labelZh}`}>
      {tone === "muted" ? (
        <span className="ev-q">?</span>
      ) : (
        <span className="ev-ladder" aria-hidden="true">
          {heights.map((h, i) => (
            <span key={i} className={`ev-rung ${i < lit ? "on" : ""}`} style={{ height: h }} />
          ))}
        </span>
      )}
      <span className="ev-txt">
        <span className="zh">{info.labelZh}</span>
        <span className="en">证据等级 · {info.labelEn}</span>
      </span>
      {(level === "unknown" || level === "RCT" || info.tier >= 3) && (
        <span className="ev-derived" title="由文献类型 + MeSH 衍生">衍生</span>
      )}
    </span>
  );
}

// ---- Metric speed-read card ---------------------------------
function Metric({ label, value, unit, sub, quartile, accent }) {
  return (
    <div className={`metric ${accent ? "accent" : ""}`}>
      <span className="mlabel">{label}</span>
      <span className="mval">{value}{unit && <span className="unit">{unit}</span>}</span>
      {quartile && <span className="qchip">{quartile}</span>}
      {sub && <span className="msub">{sub}</span>}
    </div>
  );
}

// ---- Identifier chip (copy + external) ----------------------
function IdentifierChip({ k, value, href }) {
  const [done, setDone] = React.useState(false);
  if (!value) return null;
  const onCopy = async () => {
    const ok = await copyText(value);
    if (ok) { setDone(true); showToast(`已复制 ${k} · ${value}`); setTimeout(() => setDone(false), 1400); }
  };
  return (
    <span className={`idchip ${done ? "is-done" : ""}`}>
      <button className="idcopy" type="button" onClick={onCopy}
              aria-label={`复制 ${k}：${value}`} title={`复制 ${k}`}>
        <span className="ik">{k}</span>
        <span className="iv">{value}</span>
        <span className="icg" aria-hidden="true">{done ? <IconCheck size={13} /> : <IconCopy size={13} />}</span>
      </button>
      {href && (
        <a className="ilink" href={href} target="_blank" rel="noopener noreferrer" aria-label={`在新窗口打开 ${k}`} title="打开链接 ↗">
          <IconLink size={13} />
        </a>
      )}
    </span>
  );
}

// ---- Rating table (JCR / CAS / Scopus) ----------------------
function RatingCell({ k, children, q }) {
  return (
    <div className="rcell">
      <span className="rk">{k}</span>
      <span className={`rv ${q ? "q" : ""}`}>{children}</span>
    </div>
  );
}
function RatingTable({ metrics }) {
  const { jcr, cas, scopus } = metrics || {};
  return (
    <div className="rtable">
      {jcr && (
        <div className="rsys">
          <div className="rsys-head"><span className="name">JCR · 期刊引证报告</span><span className="src">Clarivate</span></div>
          <div className="rgrid">
            <RatingCell k="影响因子">{jcr.impactFactor != null ? jcr.impactFactor.toFixed(1) : "—"}</RatingCell>
            <RatingCell k="分区" q>{jcr.quartile || "—"}</RatingCell>
            <RatingCell k="学科百分位">{jcr.percentile != null ? <>{jcr.percentile}<span className="pct">%</span></> : "—"}</RatingCell>
            <RatingCell k="排名">{jcr.rank || "—"}</RatingCell>
          </div>
          {jcr.subject && <div style={{ fontFamily: "var(--font-sans)", fontSize: "var(--text-xs)", color: "var(--fg-3)", marginTop: 7 }}>学科 · {jcr.subject}</div>}
        </div>
      )}
      {cas ? (
        <div className="rsys">
          <div className="rsys-head"><span className="name">中科院分区 · CAS</span><span className="src">中科院文献情报中心</span></div>
          <div className="rgrid" style={{ gridTemplateColumns: "repeat(2, 1fr)" }}>
            <RatingCell k="大类" q>{cas.majorCategory} · {cas.majorQuartile}</RatingCell>
            <RatingCell k="小类" q>{cas.minorSubject} · {cas.minorQuartile}</RatingCell>
          </div>
          <div className="cas-flags">
            {cas.isTop && <span className="cas-flag">Top 期刊</span>}
            {cas.isReview && <span className="cas-flag">综述期刊</span>}
            {!cas.isTop && !cas.isReview && <span className="cas-flag" style={{ background: "var(--paper-200)", color: "var(--fg-3)", borderColor: "var(--border-default)" }}>非 Top · 非综述</span>}
          </div>
        </div>
      ) : (
        <div className="rsys">
          <div className="rsys-head"><span className="name">中科院分区 · CAS</span><span className="src">CAS</span></div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--fg-3)", padding: "10px 12px", background: "var(--paper-100)", border: "1px dashed var(--border-default)", borderRadius: "var(--radius-md)" }}>
            该刊暂无中科院分区数据。
          </div>
        </div>
      )}
      {scopus && (
        <div className="rsys">
          <div className="rsys-head"><span className="name">Scopus 指标</span><span className="src">Elsevier</span></div>
          <div className="rgrid">
            <RatingCell k="CiteScore">{scopus.citeScore ?? "—"}</RatingCell>
            <RatingCell k="SJR">{scopus.sjr ?? "—"}</RatingCell>
            <RatingCell k="SNIP">{scopus.snip ?? "—"}</RatingCell>
            <RatingCell k="百分位">{scopus.percentile != null ? <>{scopus.percentile}<span className="pct">%</span></> : "—"}</RatingCell>
          </div>
        </div>
      )}
    </div>
  );
}

// ---- Trend chart (yearly works vs cited) --------------------
function TrendChart({ stats }) {
  if (!stats || !stats.length) return null;
  const maxW = Math.max(...stats.map(s => s.worksCount || 0), 1);
  const maxC = Math.max(...stats.map(s => s.citedByCount || 0), 1);
  return (
    <div className="trend">
      <div className="trend-legend">
        <span><i style={{ background: "var(--ink-800)" }} /> 年发文量</span>
        <span><i style={{ background: "var(--clay-400)" }} /> 年被引</span>
      </div>
      <div className="trend-plot">
        {stats.map(s => (
          <div className="tbar" key={s.year}>
            <div className="tbar-pair">
              <div className="tbar-col works" style={{ height: `${Math.round((s.worksCount / maxW) * 100)}%` }}
                   title={`${s.year} · 发文 ${s.worksCount.toLocaleString()}`} />
              <div className="tbar-col cited" style={{ height: `${Math.round((s.citedByCount / maxC) * 100)}%` }}
                   title={`${s.year} · 被引 ${s.citedByCount.toLocaleString()}`} />
            </div>
            <span className="tbar-yr">{String(s.year).slice(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---- Author list (deep) -------------------------------------
function AuthorList({ authors }) {
  return (
    <div className="authlist">
      {authors.map(a => (
        <div className="authrow" key={a.order}>
          <span className="ord">{a.order}</span>
          <span className="who">
            <span className="nm">
              {a.name}
              {a.isFirst && <span className="badge first">第一作者</span>}
              {a.isCorresponding && <span className="badge corr">✉ 通讯</span>}
            </span>
            {a.affiliation && <span className="aff">{a.affiliation}</span>}
          </span>
        </div>
      ))}
    </div>
  );
}

// ---- Abstract block -----------------------------------------
function AbstractBlock({ abstract }) {
  if (!abstract) {
    return <div className="abx-empty">暂无摘要 · 该来源未提供结构化或纯文本摘要</div>;
  }
  if (abstract.type === "plain") {
    return <div className="abx"><p className="abx-plain">{abstract.text}</p></div>;
  }
  return (
    <div className="abx">
      {abstract.sections.map((s, i) => (
        <div className="abx-sec" key={i}>
          <div className="abx-lbl">{s.label}<span className="zh">{s.labelZh}</span></div>
          <p className="abx-txt">{s.text}</p>
        </div>
      ))}
    </div>
  );
}

// ---- State switcher (dev tool) ------------------------------
function StateSwitcher({ value, onChange, states }) {
  return (
    <div className="switch">
      <span className="lbl">状态</span>
      <div className="switch-seg" role="group" aria-label="页面状态切换">
        {states.map(s => (
          <button key={s.id} type="button" className={value === s.id ? "on" : ""}
                  aria-pressed={value === s.id} onClick={() => onChange(s.id)}>
            {s.label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ---- Skeletons ----------------------------------------------
function SkLine({ w = "100%", h = 13, style }) {
  return <div className="sk sk-line" style={{ width: w, height: h, ...style }} />;
}
function JournalSkeleton() {
  return (
    <div className="dp-grid" aria-hidden="true">
      <div className="dp-main">
        <div className="jmast">
          <div className="sk sk-block" style={{ aspectRatio: "3 / 4" }} />
          <div className="sk-stack">
            <SkLine w="64px" h={18} />
            <SkLine w="80%" h={34} />
            <SkLine w="40%" h={34} />
            <SkLine w="70%" h={15} style={{ marginTop: 8 }} />
            <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
              <div className="sk sk-block" style={{ width: 120, height: 38 }} />
              <div className="sk sk-block" style={{ width: 100, height: 38 }} />
            </div>
          </div>
        </div>
        <div className="metric-row">
          {[0, 1, 2].map(i => <div className="sk sk-block" key={i} style={{ height: 92 }} />)}
        </div>
        <div className="sk sk-block" style={{ height: 96 }} />
        <div className="sk sk-block" style={{ height: 64 }} />
        <div className="sk sk-block" style={{ height: 64 }} />
      </div>
      <div className="dp-rail">
        <div className="sk sk-block" style={{ height: 180 }} />
        <div className="sk sk-block" style={{ height: 140 }} />
      </div>
    </div>
  );
}
function PaperSkeleton() {
  return (
    <div className="dp-grid" aria-hidden="true">
      <div className="dp-main">
        <div className="sk-stack">
          <SkLine w="120px" h={16} />
          <SkLine w="96%" h={30} />
          <SkLine w="80%" h={30} />
          <SkLine w="60%" h={15} style={{ marginTop: 10 }} />
          <SkLine w="40%" h={15} />
          <div className="sk sk-block" style={{ height: 48, width: 220, marginTop: 8 }} />
        </div>
        <div className="sk sk-block" style={{ height: 260, marginTop: 8 }} />
        <div style={{ display: "flex", gap: 10 }}>
          <div className="sk sk-block" style={{ height: 34, width: 180 }} />
          <div className="sk sk-block" style={{ height: 34, width: 140 }} />
        </div>
        <div className="sk sk-block" style={{ height: 64 }} />
        <div className="sk sk-block" style={{ height: 64 }} />
      </div>
      <div className="dp-rail">
        <div className="sk sk-block" style={{ height: 160 }} />
        <div className="sk sk-block" style={{ height: 120 }} />
      </div>
    </div>
  );
}

Object.assign(window, {
  navigate, showToast, copyText,
  IconCopy, IconCheck, IconLink, IconRefresh, IconHome, IconAlert, IconSparkle, IconCal,
  DisclosureSection, EvidenceBadge, Metric, IdentifierChip,
  RatingTable, TrendChart, AuthorList, AbstractBlock,
  StateSwitcher, SkLine, JournalSkeleton, PaperSkeleton,
});
