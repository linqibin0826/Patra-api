// =============================================================
// PATRA — journal browse/search catalog (mock).
//
// A representative ~27-journal slice of the catalog used by the
// /journals browse page. Shapes mirror the brief's list-card +
// facet fields (刊名/缩写/IF/JCR/中科院/学科/OA/国家/被引).
// The 6 homepage journals share ids + coverStyle so the
// homepage → browse → detail loop stays continuous.
//
// All metrics are realistic in shape but invented.
// =============================================================

// Subject taxonomy (zh primary · en secondary) — facet source.
const SUBJECTS = [
  { zh: "综合医学",     en: "General & Internal Medicine" },
  { zh: "综合性期刊",   en: "Multidisciplinary" },
  { zh: "肿瘤学",       en: "Oncology" },
  { zh: "心血管病学",   en: "Cardiology" },
  { zh: "神经病学",     en: "Neurology" },
  { zh: "免疫学",       en: "Immunology" },
  { zh: "细胞生物学",   en: "Cell Biology" },
  { zh: "血液学",       en: "Hematology" },
  { zh: "消化病学",     en: "Gastroenterology" },
  { zh: "肝病学",       en: "Hepatology" },
  { zh: "内分泌与代谢", en: "Endocrinology & Metabolism" },
  { zh: "传染病学",     en: "Infectious Diseases" },
  { zh: "生命科学",     en: "Life Sciences" },
];

const COUNTRIES = [
  { code: "US", zh: "美国" },
  { code: "GB", zh: "英国" },
  { code: "NL", zh: "荷兰" },
  { code: "CH", zh: "瑞士" },
  { code: "CN", zh: "中国" },
];

// jcr quartiles + cas zones for facet construction
const JCR_QUARTILES = ["Q1", "Q2", "Q3", "Q4"];
const CAS_ZONES = ["1区", "2区", "3区", "4区"];

const JOURNAL_CATALOG = [
  { id: "nejm", name: "New England Journal of Medicine", abbr: "N Engl J Med", cover: "NEJM",
    coverStyle: { bg: "#3C1611", ink: "#F6E8DA", rule: "#7C2F22" },
    impactFactor: 158.5, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "综合医学", country: "US", citedTotal: 3940000, publisher: "Massachusetts Medical Society",
    founded: 1812, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0028-4793", frequency: "每周",
    url: "https://www.nejm.org" },

  { id: "lancet", name: "The Lancet", abbr: "Lancet", cover: "Lancet",
    coverStyle: { bg: "#5A1A14", ink: "#F6E8DA", rule: "#8A2A1F" },
    impactFactor: 98.4, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "综合医学", country: "GB", citedTotal: 1820000, publisher: "Elsevier",
    founded: 1823, isOpenAccess: false, isInDoaj: false, apc: 6420, issn: "0140-6736", frequency: "每周",
    url: "https://www.thelancet.com" },

  { id: "bmj", name: "The BMJ", abbr: "BMJ", cover: "BMJ",
    coverStyle: { bg: "#0E574F", ink: "#ECF5F3", rule: "#176B62" },
    impactFactor: 105.7, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: false,
    subject: "综合医学", country: "GB", citedTotal: 410000, publisher: "BMJ Publishing Group",
    founded: 1840, isOpenAccess: true, isInDoaj: true, apc: 3690, issn: "0959-8138", frequency: "每周",
    url: "https://www.bmj.com" },

  { id: "jama", name: "Journal of the American Medical Association", abbr: "JAMA", cover: "JAMA",
    coverStyle: { bg: "#1F2E45", ink: "#E9EEF4", rule: "#3A506E" },
    impactFactor: 63.1, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "综合医学", country: "US", citedTotal: 980000, publisher: "American Medical Association",
    founded: 1883, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0098-7484", frequency: "每周",
    url: "https://jamanetwork.com" },

  { id: "nature-med", name: "Nature Medicine", abbr: "Nat Med", cover: "Nature\nMedicine",
    coverStyle: { bg: "#1C1917", ink: "#F4D9B8", rule: "#3E1C0C" },
    impactFactor: 87.2, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "综合医学", country: "GB", citedTotal: 520000, publisher: "Nature Portfolio · Springer Nature",
    founded: 1995, isOpenAccess: false, isInDoaj: false, apc: 12290, issn: "1078-8956", frequency: "每月",
    url: "https://www.nature.com/nm" },

  { id: "cell", name: "Cell", abbr: "Cell", cover: "Cell",
    coverStyle: { bg: "#6E3216", ink: "#FBF1E8", rule: "#97441E" },
    impactFactor: 66.9, jcrQuartile: "Q1", casMajor: "生物学", casQuartile: "1区", casIsTop: true,
    subject: "细胞生物学", country: "US", citedTotal: 1460000, publisher: "Cell Press · Elsevier",
    founded: 1974, isOpenAccess: false, isInDoaj: false, apc: 9900, issn: "0092-8674", frequency: "每两周",
    url: "https://www.cell.com/cell" },

  { id: "nature", name: "Nature", abbr: "Nature", cover: "Nature",
    coverStyle: { bg: "#26221E", ink: "#F0E7D8", rule: "#4A423A" },
    impactFactor: 64.8, jcrQuartile: "Q1", casMajor: "综合性期刊", casQuartile: "1区", casIsTop: true,
    subject: "综合性期刊", country: "GB", citedTotal: 3200000, publisher: "Nature Portfolio · Springer Nature",
    founded: 1869, isOpenAccess: false, isInDoaj: false, apc: 12290, issn: "0028-0836", frequency: "每周",
    url: "https://www.nature.com" },

  { id: "science", name: "Science", abbr: "Science", cover: "Science",
    coverStyle: { bg: "#233247", ink: "#E7EDF3", rule: "#3C5068" },
    impactFactor: 56.9, jcrQuartile: "Q1", casMajor: "综合性期刊", casQuartile: "1区", casIsTop: true,
    subject: "综合性期刊", country: "US", citedTotal: 2900000, publisher: "AAAS",
    founded: 1880, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0036-8075", frequency: "每周",
    url: "https://www.science.org" },

  { id: "nat-rev-cancer", name: "Nature Reviews Cancer", abbr: "Nat Rev Cancer", cover: "Nature Reviews\nCancer",
    coverStyle: { bg: "#4A1A1E", ink: "#F6E3E0", rule: "#6E2B2E" },
    impactFactor: 78.5, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "肿瘤学", country: "GB", citedTotal: 210000, publisher: "Nature Portfolio · Springer Nature",
    founded: 2001, isOpenAccess: false, isInDoaj: false, apc: null, issn: "1474-175X", frequency: "每月",
    url: "https://www.nature.com/nrc" },

  { id: "lancet-oncol", name: "The Lancet Oncology", abbr: "Lancet Oncol", cover: "The Lancet\nOncology",
    coverStyle: { bg: "#3A2233", ink: "#F3E4EC", rule: "#5A3650" },
    impactFactor: 51.1, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "肿瘤学", country: "GB", citedTotal: 180000, publisher: "Elsevier",
    founded: 2000, isOpenAccess: false, isInDoaj: false, apc: 6300, issn: "1470-2045", frequency: "每月",
    url: "https://www.thelancet.com/oncology" },

  { id: "jco", name: "Journal of Clinical Oncology", abbr: "J Clin Oncol", cover: "JCO",
    coverStyle: { bg: "#2E3D26", ink: "#EDF2E6", rule: "#45593A" },
    impactFactor: 45.3, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "肿瘤学", country: "US", citedTotal: 420000, publisher: "American Society of Clinical Oncology",
    founded: 1983, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0732-183X", frequency: "每月三期",
    url: "https://ascopubs.org/jco" },

  { id: "lancet-neurol", name: "The Lancet Neurology", abbr: "Lancet Neurol", cover: "The Lancet\nNeurology",
    coverStyle: { bg: "#143A3A", ink: "#E2F0EE", rule: "#1E5654" },
    impactFactor: 46.5, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "神经病学", country: "GB", citedTotal: 150000, publisher: "Elsevier",
    founded: 2002, isOpenAccess: false, isInDoaj: false, apc: 6300, issn: "1474-4422", frequency: "每月",
    url: "https://www.thelancet.com/neurology" },

  { id: "eur-heart-j", name: "European Heart Journal", abbr: "Eur Heart J", cover: "European\nHeart Journal",
    coverStyle: { bg: "#232A45", ink: "#E7EAF5", rule: "#3A4268" },
    impactFactor: 39.3, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "心血管病学", country: "GB", citedTotal: 240000, publisher: "Oxford University Press",
    founded: 1980, isOpenAccess: false, isInDoaj: false, apc: 4350, issn: "0195-668X", frequency: "每周",
    url: "https://academic.oup.com/eurheartj" },

  { id: "circulation", name: "Circulation", abbr: "Circulation", cover: "Circulation",
    coverStyle: { bg: "#5A2A18", ink: "#F8E9DD", rule: "#834024" },
    impactFactor: 37.8, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "心血管病学", country: "US", citedTotal: 460000, publisher: "AHA · Wolters Kluwer",
    founded: 1950, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0009-7322", frequency: "每周",
    url: "https://www.ahajournals.org/journal/circ" },

  { id: "ann-intern-med", name: "Annals of Internal Medicine", abbr: "Ann Intern Med", cover: "Annals of\nInternal Medicine",
    coverStyle: { bg: "#2F3A42", ink: "#E9EEF1", rule: "#46555E" },
    impactFactor: 39.2, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: false,
    subject: "综合医学", country: "US", citedTotal: 160000, publisher: "American College of Physicians",
    founded: 1927, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0003-4819", frequency: "每月",
    url: "https://www.acpjournals.org/journal/aim" },

  { id: "immunity", name: "Immunity", abbr: "Immunity", cover: "Immunity",
    coverStyle: { bg: "#3A3618", ink: "#F2EDDC", rule: "#585326" },
    impactFactor: 32.4, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "免疫学", country: "US", citedTotal: 220000, publisher: "Cell Press · Elsevier",
    founded: 1994, isOpenAccess: false, isInDoaj: false, apc: 9500, issn: "1074-7613", frequency: "每月",
    url: "https://www.cell.com/immunity" },

  { id: "j-hepatol", name: "Journal of Hepatology", abbr: "J Hepatol", cover: "Journal of\nHepatology",
    coverStyle: { bg: "#2B3947", ink: "#E8EDF2", rule: "#41525F" },
    impactFactor: 26.8, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "肝病学", country: "NL", citedTotal: 130000, publisher: "Elsevier",
    founded: 1985, isOpenAccess: false, isInDoaj: false, apc: 4500, issn: "0168-8278", frequency: "每月",
    url: "https://www.journal-of-hepatology.eu" },

  { id: "gut", name: "Gut", abbr: "Gut", cover: "Gut",
    coverStyle: { bg: "#1E3A2E", ink: "#E4F0E8", rule: "#2E5642" },
    impactFactor: 24.5, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "消化病学", country: "GB", citedTotal: 190000, publisher: "BMJ Publishing Group",
    founded: 1960, isOpenAccess: false, isInDoaj: false, apc: 3690, issn: "0017-5749", frequency: "每月",
    url: "https://gut.bmj.com" },

  { id: "blood", name: "Blood", abbr: "Blood", cover: "Blood",
    coverStyle: { bg: "#4A171A", ink: "#F6E5E2", rule: "#6E2A2C" },
    impactFactor: 21.0, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: false,
    subject: "血液学", country: "US", citedTotal: 540000, publisher: "American Society of Hematology",
    founded: 1946, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0006-4971", frequency: "每周",
    url: "https://ashpublications.org/blood" },

  { id: "diabetes-care", name: "Diabetes Care", abbr: "Diabetes Care", cover: "Diabetes\nCare",
    coverStyle: { bg: "#4A3312", ink: "#F7ECD6", rule: "#6E4E20" },
    impactFactor: 16.2, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: true,
    subject: "内分泌与代谢", country: "US", citedTotal: 280000, publisher: "American Diabetes Association",
    founded: 1978, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0149-5992", frequency: "每月",
    url: "https://diabetesjournals.org/care" },

  { id: "plos-med", name: "PLOS Medicine", abbr: "PLOS Med", cover: "PLOS\nMedicine",
    coverStyle: { bg: "#7A3A1C", ink: "#FBEDE2", rule: "#A4502A" },
    impactFactor: 15.8, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: false,
    subject: "综合医学", country: "US", citedTotal: 90000, publisher: "Public Library of Science",
    founded: 2004, isOpenAccess: true, isInDoaj: true, apc: 5300, issn: "1549-1277", frequency: "每月",
    url: "https://journals.plos.org/plosmedicine" },

  { id: "j-infect-dis", name: "The Journal of Infectious Diseases", abbr: "J Infect Dis", cover: "Journal of\nInfectious Diseases",
    coverStyle: { bg: "#25324A", ink: "#E8EDF4", rule: "#3E4F6E" },
    impactFactor: 5.0, jcrQuartile: "Q2", casMajor: "医学", casQuartile: "2区", casIsTop: false,
    subject: "传染病学", country: "US", citedTotal: 140000, publisher: "Oxford University Press",
    founded: 1904, isOpenAccess: false, isInDoaj: false, apc: 4150, issn: "0022-1899", frequency: "每两周",
    url: "https://academic.oup.com/jid" },

  { id: "elife", name: "eLife", abbr: "eLife", cover: "eLife",
    coverStyle: { bg: "#36462C", ink: "#EEF3E7", rule: "#506540" },
    impactFactor: 7.7, jcrQuartile: "Q1", casMajor: "生物学", casQuartile: "2区", casIsTop: false,
    subject: "生命科学", country: "GB", citedTotal: 120000, publisher: "eLife Sciences Publications",
    founded: 2012, isOpenAccess: true, isInDoaj: true, apc: 2500, issn: "2050-084X", frequency: "连续出版",
    url: "https://elifesciences.org" },

  { id: "bmc-med", name: "BMC Medicine", abbr: "BMC Med", cover: "BMC\nMedicine",
    coverStyle: { bg: "#18504A", ink: "#E4F1EF", rule: "#246C64" },
    impactFactor: 9.3, jcrQuartile: "Q1", casMajor: "医学", casQuartile: "1区", casIsTop: false,
    subject: "综合医学", country: "GB", citedTotal: 70000, publisher: "BMC · Springer Nature",
    founded: 2003, isOpenAccess: true, isInDoaj: true, apc: 4290, issn: "1741-7015", frequency: "连续出版",
    url: "https://bmcmedicine.biomedcentral.com" },

  { id: "front-immunol", name: "Frontiers in Immunology", abbr: "Front Immunol", cover: "Frontiers in\nImmunology",
    coverStyle: { bg: "#2A2C4A", ink: "#E9EAF5", rule: "#44476E" },
    impactFactor: 5.7, jcrQuartile: "Q2", casMajor: "医学", casQuartile: "2区", casIsTop: false,
    subject: "免疫学", country: "CH", citedTotal: 160000, publisher: "Frontiers Media",
    founded: 2010, isOpenAccess: true, isInDoaj: true, apc: 3115, issn: "1664-3224", frequency: "连续出版",
    url: "https://www.frontiersin.org/journals/immunology" },

  { id: "chin-med-j", name: "Chinese Medical Journal", abbr: "Chin Med J", cover: "Chinese\nMedical Journal",
    coverStyle: { bg: "#4E1B17", ink: "#F7E6E2", rule: "#732E27" },
    impactFactor: 3.2, jcrQuartile: "Q2", casMajor: "医学", casQuartile: "3区", casIsTop: false,
    subject: "综合医学", country: "CN", citedTotal: 40000, publisher: "Chinese Medical Association · Wolters Kluwer",
    founded: 1887, isOpenAccess: false, isInDoaj: false, apc: null, issn: "0366-6999", frequency: "每半月",
    url: "https://journals.lww.com/cmj" },

  { id: "world-j-gastro", name: "World Journal of Gastroenterology", abbr: "World J Gastroenterol", cover: "World J\nGastroenterology",
    coverStyle: { bg: "#233E2C", ink: "#E5F0E8", rule: "#356048" },
    impactFactor: 4.3, jcrQuartile: "Q3", casMajor: "医学", casQuartile: "3区", casIsTop: false,
    subject: "消化病学", country: "CN", citedTotal: 110000, publisher: "Baishideng Publishing Group",
    founded: 1995, isOpenAccess: true, isInDoaj: true, apc: 2685, issn: "1007-9327", frequency: "每周",
    url: "https://www.wjgnet.com" },
];

// ── lookups ──────────────────────────────────────────────────
const SUBJECT_EN = Object.fromEntries(SUBJECTS.map(s => [s.zh, s.en]));
const COUNTRY_ZH = Object.fromEntries(COUNTRIES.map(c => [c.code, c.zh]));

// ── facet count helper ──────────────────────────────────────
// Given the working set already narrowed by query + OTHER groups,
// count how many journals fall into each option of one group.
function countBy(list, keyFn) {
  const m = new Map();
  for (const j of list) {
    const k = keyFn(j);
    if (k == null) continue;
    m.set(k, (m.get(k) || 0) + 1);
  }
  return m;
}

// ── detail resolver fallback ────────────────────────────────
// Build a JournalBody-shaped record from a catalog entry so that
// every browse card has a real /journals/[id] landing page. The
// 6 homepage journals are handled upstream (JOURNAL_RICH / synth);
// this covers the other ~21.
function resolveCatalogJournal(id) {
  const c = JOURNAL_CATALOG.find(x => x.id === id);
  if (!c) return null;
  const worksApprox = Math.round((c.citedTotal / 1000) * (c.impactFactor > 40 ? 0.5 : 1.4));
  return {
    id: c.id,
    name: c.name,
    abbr: c.abbr,
    cover: c.cover,
    coverStyle: c.coverStyle,
    publisher: c.publisher,
    issnList: [c.issn],
    country: c.country,
    countryName: COUNTRY_ZH[c.country] || c.country,
    foundedYear: c.founded,
    subjectAreas: [SUBJECT_EN[c.subject] || c.subject, c.subject],
    isOpenAccess: c.isOpenAccess,
    homepageUrl: c.url || null,
    metrics: {
      jcr: { impactFactor: c.impactFactor, quartile: c.jcrQuartile, percentile: null, rank: null,
             subject: SUBJECT_EN[c.subject] || null },
      cas: { majorCategory: c.casMajor, majorQuartile: c.casQuartile,
             minorSubject: SUBJECT_EN[c.subject] || c.subject, minorQuartile: c.casQuartile,
             isTop: c.casIsTop, isReview: false },
      scopus: null,
      bibliometric: { hIndex: null, i10Index: null, citedByCount: c.citedTotal, worksCount: worksApprox },
    },
    publicationProfile: { frequency: c.frequency, medlineIndexed: "Currently-indexed", languages: ["en"], startYear: c.founded },
    openAccess: { isOa: c.isOpenAccess, oaType: c.isOpenAccess ? "gold" : "hybrid", apcUsd: c.apc, isInDoaj: c.isInDoaj },
    yearlyStats: [],
    affiliatedSocieties: [],
  };
}

Object.assign(window, {
  SUBJECTS, COUNTRIES, JCR_QUARTILES, CAS_ZONES,
  JOURNAL_CATALOG, SUBJECT_EN, COUNTRY_ZH,
  countBy, resolveCatalogJournal,
});
