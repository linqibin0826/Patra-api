// =============================================================
// PATRA — detail page compositions.
//   JournalDetail  /journals/[id]
//   PaperDetail    /papers/[id]
// Each owns a dev StateSwitcher (default / loading / error / 404
// / 字段降级) so every required state is reachable in-page.
// Default layer always visible; deep-data layer = stacked
// DisclosureSection (same-page progressive disclosure).
// =============================================================

const DETAIL_STATES = [
  { id: "default", label: "默认" },
  { id: "loading", label: "加载中" },
  { id: "error", label: "错误" },
  { id: "notfound", label: "404" },
];
const PAPER_STATES = [...DETAIL_STATES, { id: "degraded", label: "字段降级" }];

// ============================================================
// JOURNAL DETAIL
// ============================================================
function JournalDetail({ id }) {
  const [state, setState] = React.useState("default");
  const journal = resolveJournal(id);
  const effState = !journal ? "notfound" : state;

  return (
    <div className="dp" data-screen-label="Journal detail">
      <div className="dp-bar">
        <div className="container dp-bar-row">
          <nav className="crumbs" aria-label="面包屑">
            <a href="#/" onClick={(e) => { e.preventDefault(); navigate("#/"); }}>Patra</a>
            <span className="sep">/</span>
            <a className="mid" href="#/" onClick={(e) => { e.preventDefault(); navigate("#/"); }}>期刊</a>
            <span className="sep mid">/</span>
            <span className="here">{journal ? journal.abbr : id}</span>
          </nav>
          <StateSwitcher value={effState} onChange={setState} states={DETAIL_STATES} />
        </div>
      </div>

      <div className="container">
        {effState === "loading" && <JournalSkeleton />}
        {effState === "error" && <ErrorState context="加载期刊" onRetry={() => setState("default")} detail="cat_venue fetch failed · upstream 503" />}
        {effState === "notfound" && <NotFoundState kind="journal" id={id} />}
        {effState === "default" && journal && <JournalBody journal={journal} />}
      </div>
    </div>
  );
}

function JournalBody({ journal: j }) {
  const m = j.metrics || {};
  const hasCover = !!j.cover;
  const { bg, ink } = j.coverStyle || {};

  // metric speed-read — only render cards we actually have
  const metricCards = [];
  if (m.jcr && m.jcr.impactFactor != null)
    metricCards.push(<Metric key="if" accent label="JCR 影响因子" value={m.jcr.impactFactor.toFixed(1)} sub="最新年度" />);
  if (m.jcr && m.jcr.quartile)
    metricCards.push(<Metric key="q" label="JCR 分区" value={m.jcr.quartile} sub={m.jcr.rank ? `排名 ${m.jcr.rank}` : "综合医学"} />);
  if (m.cas)
    metricCards.push(<Metric key="cas" label="中科院分区" value={m.cas.majorQuartile} sub={`${m.cas.majorCategory}${m.cas.isTop ? " · Top" : ""}`} />);
  else if (m.scopus)
    metricCards.push(<Metric key="cs" label="Scopus CiteScore" value={m.scopus.citeScore} sub={m.scopus.percentile ? `${m.scopus.percentile}% 百分位` : ""} />);

  const bib = m.bibliometric;
  const oa = j.openAccess || {};

  return (
    <div className="dp-grid">
      <div className="dp-main">
        {/* ── default layer ─────────────────────────────── */}
        <header className="jmast">
          {hasCover ? (
            <div className="jmast-cover" style={{ background: bg, color: ink }}>
              <span className="word">{j.cover}</span>
              <span className="est">est. {j.foundedYear}</span>
            </div>
          ) : (
            <div className="jmast-cover noimg">
              <span className="ph"><IconBook size={22} /> 暂无封面</span>
            </div>
          )}
          <div className="jmast-id">
            {oa.isOa
              ? <span className="jmast-oa"><IconLeaf size={12} /> 开放获取</span>
              : <span className="jmast-oa" style={{ borderColor: "var(--border-default)", color: "var(--fg-3)", background: "var(--paper-100)" }}>订阅 · 混合 OA</span>}
            <h1 className="jmast-name">{j.name}</h1>
            <div className="jmast-abbr">{j.abbr}</div>
            <div className="jmast-facts">
              {j.publisher && j.publisher !== "—" && <span>{j.publisher}</span>}
              {j.issnList && j.issnList[0] && j.issnList[0] !== "XXXX-XXXX" && <span className="mono">ISSN {j.issnList[0]}</span>}
              {j.countryName && <span>{j.countryName}</span>}
              {j.foundedYear && <span>创刊 {j.foundedYear}</span>}
            </div>
            <div className="jmast-cta">
              {j.homepageUrl ? (
                <a className="btn btn-primary" href={j.homepageUrl} target="_blank" rel="noopener noreferrer">
                  访问期刊官网 <IconExternal size={14} />
                </a>
              ) : (
                <button className="btn btn-sec" type="button" disabled style={{ opacity: 0.55, cursor: "not-allowed" }} title="官网链接待采集">
                  官网链接待采集
                </button>
              )}
            </div>
          </div>
        </header>

        {metricCards.length > 0 && (
          <section>
            <p className="dp-eyebrow"><span className="leaf"><PatraMark height={14} /></span> 影响力速览</p>
            <div className="metric-row">{metricCards}</div>
          </section>
        )}

        {/* 定位 — structured facts, not editorial prose */}
        <section className="jpos">
          <p className="dp-eyebrow" style={{ margin: 0, marginBottom: 12 }}><span className="leaf"><PatraMark height={14} /></span> 定位与范围</p>
          <p className="note">由结构化事实组合 —— 该刊暂无编辑撰写的简介文本。</p>
          <div className="tagrow">
            {j.subjectAreas && j.subjectAreas.map((s, i) => <span className="tag" key={i}><span className="k">学科</span>{s}</span>)}
            <span className="tag"><span className="k">出版</span>{j.publicationProfile?.frequency || "—"}</span>
            <span className="tag"><span className="k">索引</span>MEDLINE · {j.publicationProfile?.medlineIndexed === "Currently-indexed" ? "当前收录" : j.publicationProfile?.medlineIndexed}</span>
            <span className="tag"><span className="k">获取</span>{oa.isOa ? `开放获取 · ${oa.oaType}` : "订阅 / 混合"}</span>
          </div>
        </section>

        {/* ── deep-data layer (collapsed) ──────────────── */}
        <section>
          <p className="dp-eyebrow"><span className="leaf"><PatraMark height={14} /></span> 深度数据 · 按需展开</p>
          <div>
            <DisclosureSection title="完整评级明细" count="JCR · CAS · Scopus" defaultOpen>
              <RatingTable metrics={m} />
            </DisclosureSection>

            {(bib || (j.yearlyStats && j.yearlyStats.length > 0)) && (
              <DisclosureSection title="文献计量与趋势">
                {bib && (
                  <dl className="deflist" style={{ marginBottom: j.yearlyStats?.length ? 22 : 0 }}>
                    <dt>h-index</dt><dd className="mono">{bib.hIndex?.toLocaleString() ?? "—"}</dd>
                    <dt>i10-index</dt><dd className="mono">{bib.i10Index != null ? bib.i10Index.toLocaleString() : "—"}</dd>
                    <dt>被引总数</dt><dd className="mono">{bib.citedByCount?.toLocaleString() ?? "—"}</dd>
                    <dt>累计发文</dt><dd className="mono">{bib.worksCount?.toLocaleString() ?? "—"}</dd>
                  </dl>
                )}
                {j.yearlyStats && j.yearlyStats.length > 0 && <TrendChart stats={j.yearlyStats} />}
              </DisclosureSection>
            )}

            <DisclosureSection title="收录与出版">
              <dl className="deflist">
                <dt>出版频率</dt><dd>{j.publicationProfile?.frequency || "—"}</dd>
                <dt>创刊年</dt><dd className="mono">{j.publicationProfile?.startYear || j.foundedYear || "—"}</dd>
                <dt>MEDLINE 索引</dt><dd>{j.publicationProfile?.medlineIndexed === "Currently-indexed" ? "当前收录中" : (j.publicationProfile?.medlineIndexed || "—")}</dd>
                <dt>语言</dt><dd>{(j.publicationProfile?.languages || []).map(l => l === "en" ? "英语" : l).join(" · ") || "—"}</dd>
                <dt>国家 / 地区</dt><dd>{j.countryName || "—"}</dd>
              </dl>
            </DisclosureSection>

            <DisclosureSection title="开放获取细节">
              <dl className="deflist">
                <dt>OA 类型</dt><dd>{oa.isOa ? (oa.oaType === "gold" ? "完全开放 · Gold" : oa.oaType) : "混合 OA · Hybrid"}</dd>
                {oa.apcUsd != null && <><dt>APC 费用</dt><dd className="mono">US$ {oa.apcUsd.toLocaleString()}</dd></>}
                <dt>DOAJ 收录</dt><dd>{oa.isInDoaj ? "是" : "否"}</dd>
              </dl>
            </DisclosureSection>

            <DisclosureSection title="关系与标识">
              <dl className="deflist">
                <dt>关联学会</dt><dd>{(j.affiliatedSocieties && j.affiliatedSocieties.length) ? j.affiliatedSocieties.join(" · ") : "—"}</dd>
                <dt>出版商</dt><dd>{j.publisher || "—"}</dd>
              </dl>
              <div className="idrow" style={{ marginTop: 14 }}>
                {(j.issnList || []).filter(x => x !== "XXXX-XXXX").map((issn, i) => (
                  <IdentifierChip key={i} k={i === 0 ? "ISSN-L" : "ISSN"} value={issn} />
                ))}
              </div>
            </DisclosureSection>
          </div>
        </section>
      </div>

      {/* ── rail ──────────────────────────────────────── */}
      <aside className="dp-rail">
        <div className="rail-card accent">
          <div className="rc-eyebrow"><PatraMark height={13} /> 本刊速览</div>
          <div className="rail-stats">
            {m.jcr?.impactFactor != null && <div className="rail-stat"><span className="k">影响因子</span><span className="v serif">{m.jcr.impactFactor.toFixed(1)}</span></div>}
            {m.jcr?.quartile && <div className="rail-stat"><span className="k">JCR 分区</span><span className="v">{m.jcr.quartile}</span></div>}
            {m.cas && <div className="rail-stat"><span className="k">中科院</span><span className="v">{m.cas.majorCategory} {m.cas.majorQuartile}</span></div>}
            {bib?.hIndex != null && <div className="rail-stat"><span className="k">h-index</span><span className="v">{bib.hIndex.toLocaleString()}</span></div>}
            {bib?.citedByCount != null && <div className="rail-stat"><span className="k">被引总数</span><span className="v">{(bib.citedByCount / 1e6).toFixed(2)}M</span></div>}
            <div className="rail-stat"><span className="k">创刊</span><span className="v">{j.foundedYear || "—"}</span></div>
          </div>
          {j.homepageUrl && (
            <a className="btn btn-primary btn-block" style={{ marginTop: 14 }} href={j.homepageUrl} target="_blank" rel="noopener noreferrer">
              访问官网 <IconExternal size={14} />
            </a>
          )}
        </div>

        <div className="rail-card">
          <div className="rc-eyebrow">边界 · v0.5</div>
          <p style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--fg-3)", lineHeight: 1.5 }}>
            本页用于认识与评估期刊，<b style={{ color: "var(--fg-2)" }}>不含该刊的文献列表</b>。文献浏览将在后续版本提供。
          </p>
        </div>
      </aside>
    </div>
  );
}

// ============================================================
// PAPER DETAIL
// ============================================================
function PaperDetail({ id }) {
  const [state, setState] = React.useState("default");
  const [bookmarked, setBookmarked] = React.useState(false);
  const base = resolvePaper(id);
  const effState = !base ? "notfound" : state;
  const paper = base && state === "degraded" ? degradePaper(base) : base;

  return (
    <div className="dp" data-screen-label="Paper detail">
      <div className="dp-bar">
        <div className="container dp-bar-row">
          <nav className="crumbs" aria-label="面包屑">
            <a href="#/" onClick={(e) => { e.preventDefault(); navigate("#/"); }}>Patra</a>
            <span className="sep">/</span>
            <a className="mid" href="#/" onClick={(e) => { e.preventDefault(); navigate("#/"); }}>文献</a>
            <span className="sep mid">/</span>
            <span className="here mono">{base ? (base.identifiers?.pmid || id) : id}</span>
          </nav>
          <StateSwitcher value={effState} onChange={setState} states={PAPER_STATES} />
        </div>
      </div>

      <div className="container">
        {effState === "loading" && <PaperSkeleton />}
        {effState === "error" && <ErrorState context="加载文献" onRetry={() => setState("default")} detail="cat_publication fetch failed · timeout" />}
        {effState === "notfound" && <NotFoundState kind="paper" id={id} />}
        {(effState === "default" || effState === "degraded") && paper &&
          <PaperBody paper={paper} bookmarked={bookmarked} setBookmarked={setBookmarked} />}
      </div>
    </div>
  );
}

function bylineAuthors(authors, total) {
  const shown = authors.slice(0, 3);
  const extra = total - shown.length;
  return { shown, extra: extra > 0 ? extra : 0 };
}

function PaperBody({ paper: p, bookmarked, setBookmarked }) {
  const { shown, extra } = bylineAuthors(p.authors, p.authorCount);
  const ev = EVIDENCE_LEVELS[p.evidenceLevel] || EVIDENCE_LEVELS.unknown;
  const mesh = p.meshHeadings || [];
  const funding = p.funding || [];
  const fullHref = p.oaUrl || (p.identifiers?.doi ? `https://doi.org/${p.identifiers.doi}` : null);

  return (
    <div className="dp-grid">
      <div className="dp-main">
        {/* ── default layer ─────────────────────────────── */}
        <header>
          <div className="ph-top">
            {(p.publicationType || []).slice(0, 2).map((t, i) => <span className="ph-type" key={i}>{t}</span>)}
            {p.isOa && <span className="ph-oa"><IconLeaf size={11} /> 开放获取</span>}
          </div>
          <h1 className="ph-title">{p.title}</h1>
          {p.originalTitle && <p className="ph-original">{p.originalTitle}</p>}

          <div className="ph-byline">
            {shown.map((a, i) => (
              <span className="a" key={i}>
                {a.name}{a.isCorresponding && <span className="corr" title="通讯作者"> ✉</span>}{i < shown.length - 1 ? "、" : ""}
              </span>
            ))}
            {extra > 0 && <span className="etal">&nbsp;等 {extra} 位</span>}
            <span className="dot" />
            {p.venue?.id
              ? <a className="jlink" href={`#/journals/${p.venue.id}`} onClick={(e) => { e.preventDefault(); navigate(`#/journals/${p.venue.id}`); }}>{p.venue.name}</a>
              : <span className="jlink" style={{ color: "var(--ink-800)", textDecoration: "none", cursor: "default" }}>{p.venue?.name}</span>}
            <span className="yr">&nbsp;· {p.venue?.year}</span>
            {p.volumeInfo && p.evidenceLevel !== "unknown" && <><span className="dot" /><span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--fg-3)" }}>{p.volumeInfo}</span></>}
          </div>

          <div style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center", marginBottom: 6 }}>
            <EvidenceBadge level={p.evidenceLevel} />
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {fullHref ? (
                <a className="btn btn-primary" href={fullHref} target="_blank" rel="noopener noreferrer">
                  去全文 {p.isOa ? "· OA" : "· DOI"} <IconExternal size={14} />
                </a>
              ) : (
                <button className="btn btn-sec" type="button" disabled style={{ opacity: 0.55, cursor: "not-allowed" }}>全文链接不可用</button>
              )}
              <button className={`btn btn-sec ${bookmarked ? "" : ""}`} type="button" onClick={() => { setBookmarked(b => !b); showToast(bookmarked ? "已取消收藏（mock）" : "已收藏（mock）"); }} aria-pressed={bookmarked}>
                {bookmarked ? <IconStarFill size={14} /> : <IconStar size={14} />} {bookmarked ? "已收藏" : "收藏"}
              </button>
            </div>
          </div>
        </header>

        {/* abstract — page core */}
        <section>
          <p className="dp-eyebrow"><span className="leaf"><PatraMark height={14} /></span> 摘要</p>
          <AbstractBlock abstract={p.abstract} />
        </section>

        {/* key identifiers (default layer) */}
        <section>
          <p className="dp-eyebrow"><span className="leaf"><PatraMark height={14} /></span> 关键标识</p>
          <div className="idrow">
            <IdentifierChip k="DOI" value={p.identifiers?.doi} href={p.identifiers?.doi ? `https://doi.org/${p.identifiers.doi}` : null} />
            <IdentifierChip k="PMID" value={p.identifiers?.pmid} href={p.identifiers?.pmid ? `https://pubmed.ncbi.nlm.nih.gov/${p.identifiers.pmid}` : null} />
          </div>
        </section>

        {/* ── deep-data layer (collapsed) ──────────────── */}
        <section>
          <p className="dp-eyebrow"><span className="leaf"><PatraMark height={14} /></span> 深度数据 · 按需展开</p>
          <div>
            <DisclosureSection title="完整作者与机构" count={`${p.authorCount} 位`}>
              <AuthorList authors={p.authors} />
              {p.authorCount > p.authors.length && (
                <p style={{ margin: "12px 0 0", fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--fg-3)" }}>
                  另有 {p.authorCount - p.authors.length} 位作者未展开 · 完整名单见原文
                </p>
              )}
            </DisclosureSection>

            {mesh.length > 0 && (
              <DisclosureSection title="MeSH 主题词 / 关键词" count={`${mesh.length} 项`}>
                <div className="meshrow">
                  {mesh.map((h, i) => (
                    <span className={`mesh ${h.major ? "major" : ""}`} key={i}>
                      {h.major && <span className="star" title="主要主题词">★</span>}{h.term}
                    </span>
                  ))}
                </div>
                {p.keywords && p.keywords.length > 0 && (
                  <div className="meshrow" style={{ marginTop: 12 }}>
                    {p.keywords.map((k, i) => <span className="mesh" key={i} style={{ fontFamily: "var(--font-mono)", fontSize: "11px" }}>#{k}</span>)}
                  </div>
                )}
              </DisclosureSection>
            )}

            {funding.length > 0 && (
              <DisclosureSection title="资助信息" count={`${funding.length} 项`}>
                <dl className="deflist">
                  {funding.map((f, i) => (
                    <React.Fragment key={i}>
                      <dt>资助方</dt>
                      <dd>{f.funder}{f.grantId && <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--fg-3)", marginLeft: 8 }}>· {f.grantId}</span>}</dd>
                    </React.Fragment>
                  ))}
                </dl>
              </DisclosureSection>
            )}

            {(p.identifiers?.pmcid || p.identifiers?.pii) && (
              <DisclosureSection title="其他标识符">
                <div className="idrow">
                  {p.identifiers.pmcid && <IdentifierChip k="PMCID" value={p.identifiers.pmcid} href={`https://www.ncbi.nlm.nih.gov/pmc/articles/${p.identifiers.pmcid}/`} />}
                  {p.identifiers.pii && <IdentifierChip k="PII" value={p.identifiers.pii} />}
                </div>
              </DisclosureSection>
            )}

            {p.dates && (
              <DisclosureSection title="各类日期">
                <dl className="deflist">
                  {p.dates.received && <><dt>投稿</dt><dd className="mono">{p.dates.received}</dd></>}
                  {p.dates.accepted && <><dt>接收</dt><dd className="mono">{p.dates.accepted}</dd></>}
                  {p.dates.ePublished && <><dt>电子出版</dt><dd className="mono">{p.dates.ePublished}</dd></>}
                  {p.dates.published && <><dt>正式出版</dt><dd className="mono">{p.dates.published}</dd></>}
                </dl>
              </DisclosureSection>
            )}

            <DisclosureSection title="参考文献与声明">
              <dl className="deflist">
                <dt>参考文献数</dt><dd className="mono">{p.numberOfReferences != null ? p.numberOfReferences : "—"}</dd>
                <dt>利益冲突</dt><dd>{p.conflictOfInterest || "未声明 / 暂无数据"}</dd>
              </dl>
            </DisclosureSection>
          </div>
        </section>
      </div>

      {/* ── rail ──────────────────────────────────────── */}
      <aside className="dp-rail">
        <div className="rail-card">
          <div className="rc-eyebrow">操作</div>
          <div className="rail-actions">
            {fullHref ? (
              <a className="btn btn-primary btn-block" href={fullHref} target="_blank" rel="noopener noreferrer">
                去全文 {p.isOa ? "· OA" : "· DOI"} <IconExternal size={14} />
              </a>
            ) : (
              <button className="btn btn-sec btn-block" type="button" disabled style={{ opacity: 0.55, cursor: "not-allowed" }}>全文链接不可用</button>
            )}
            <button className="btn btn-sec btn-block" type="button" onClick={() => { setBookmarked(b => !b); showToast(bookmarked ? "已取消收藏（mock）" : "已收藏（mock）"); }} aria-pressed={bookmarked}>
              {bookmarked ? <IconStarFill size={14} /> : <IconStar size={14} />} {bookmarked ? "已收藏" : "收藏"}
            </button>
          </div>
        </div>

        <div className="rail-card accent">
          <div className="ai-mock">
            <div className="ai-mock-head">
              <PatraMark height={16} /> AI 速读
              <span className="auto">mock · 占位</span>
            </div>
            {p.aiSummary ? (
              <p className="ai-mock-body" style={{ margin: 0 }}>{p.aiSummary}</p>
            ) : (
              <p className="ai-mock-body" style={{ margin: 0, color: "var(--fg-3)", fontStyle: "italic" }}>尚未生成 AI 速读。</p>
            )}
            <button className="ai-mock-gen" type="button" onClick={() => showToast("AI 速读为本版占位（mock），未接真实模型")}>
              <IconSparkle size={13} /> {p.aiSummary ? "重新生成" : "生成速读"}
            </button>
          </div>
        </div>

        <div className="rail-card">
          <div className="rc-eyebrow">速览</div>
          <div className="rail-stats">
            <div className="rail-stat"><span className="k">证据等级</span><span className="v" style={{ color: ev.tone === "muted" ? "var(--fg-3)" : "var(--ink-900)" }}>{ev.labelZh}</span></div>
            <div className="rail-stat"><span className="k">被引</span><span className="v">{(p.cites ?? 0).toLocaleString()}</span></div>
            <div className="rail-stat"><span className="k">收藏</span><span className="v">{((p.bookmarks ?? 0) + (bookmarked ? 1 : 0)).toLocaleString()}</span></div>
            <div className="rail-stat"><span className="k">原文阅读</span><span className="v">≈ {p.readMin} 分钟</span></div>
            <div className="rail-stat"><span className="k">来源</span><span className="v" style={{ fontFamily: "var(--font-sans)" }}>{p.source}</span></div>
          </div>
        </div>
      </aside>
    </div>
  );
}

Object.assign(window, { JournalDetail, PaperDetail });
