// =============================================================
// PATRA — detail-page mock data (journal + paper).
//
// Shapes mirror the brief's "ideal field" samples. Where the
// real DTO has gaps (homepage ↗ §附录A), records are authored so
// the page can demonstrate BOTH full data and field-level
// degradation (missing module → hide, never an empty placeholder).
//
// Resolvers turn a homepage id into a full detail record so the
// homepage → detail → journal loop is real and titles match.
// All identifiers are realistic in shape but invented; abstracts
// are paraphrased / synthetic.
// =============================================================

// ─── Journals ────────────────────────────────────────────────
// Rich records carry all three rating systems + bibliometrics +
// yearly trend. Synthesized records (built from the homepage
// JOURNALS array) intentionally omit CAS / Scopus / trend so the
// page exercises its degradation paths.

const JOURNAL_RICH = {
  nejm: {
    id: "nejm",
    name: "New England Journal of Medicine",
    abbr: "N Engl J Med",
    cover: "NEJM",
    coverStyle: { bg: "#3C1611", ink: "#F6E8DA", rule: "#7C2F22" },
    publisher: "Massachusetts Medical Society",
    issnList: ["0028-4793", "1533-4406"],
    country: "US",
    countryName: "美国",
    foundedYear: 1812,
    subjectAreas: ["General & Internal Medicine", "综合医学"],
    isOpenAccess: false,
    homepageUrl: "https://www.nejm.org",
    metrics: {
      jcr: { impactFactor: 158.5, quartile: "Q1", percentile: 99.7, rank: "1/325", subject: "Medicine, General & Internal" },
      cas: { majorCategory: "医学", majorQuartile: "1区", minorSubject: "医学：内科", minorQuartile: "1区", isTop: true, isReview: false },
      scopus: { citeScore: 122.4, sjr: 31.8, snip: 26.5, percentile: 99 },
      bibliometric: { hIndex: 1186, i10Index: null, citedByCount: 3940000, worksCount: 31200 },
    },
    publicationProfile: { frequency: "每周", medlineIndexed: "Currently-indexed", languages: ["en"], startYear: 1812 },
    openAccess: { isOa: false, oaType: "hybrid", apcUsd: null, isInDoaj: false },
    yearlyStats: [
      { year: 2019, worksCount: 1180, citedByCount: 168000 },
      { year: 2020, worksCount: 1410, citedByCount: 252000 },
      { year: 2021, worksCount: 1360, citedByCount: 288000 },
      { year: 2022, worksCount: 1240, citedByCount: 264000 },
      { year: 2023, worksCount: 1190, citedByCount: 241000 },
      { year: 2024, worksCount: 1205, citedByCount: 233000 },
    ],
    affiliatedSocieties: ["Massachusetts Medical Society"],
  },
  lancet: {
    id: "lancet",
    name: "The Lancet",
    abbr: "Lancet",
    cover: "Lancet",
    coverStyle: { bg: "#5A1A14", ink: "#F6E8DA", rule: "#8A2A1F" },
    publisher: "Elsevier",
    issnList: ["0140-6736", "1474-547X"],
    country: "GB",
    countryName: "英国",
    foundedYear: 1823,
    subjectAreas: ["General & Internal Medicine", "综合医学"],
    isOpenAccess: false,
    homepageUrl: "https://www.thelancet.com",
    metrics: {
      jcr: { impactFactor: 98.4, quartile: "Q1", percentile: 99.2, rank: "2/325", subject: "Medicine, General & Internal" },
      cas: { majorCategory: "医学", majorQuartile: "1区", minorSubject: "医学：内科", minorQuartile: "1区", isTop: true, isReview: false },
      scopus: { citeScore: 84.7, sjr: 15.6, snip: 21.3, percentile: 99 },
      bibliometric: { hIndex: 812, i10Index: null, citedByCount: 1820000, worksCount: 24500 },
    },
    publicationProfile: { frequency: "每周", medlineIndexed: "Currently-indexed", languages: ["en"], startYear: 1823 },
    openAccess: { isOa: false, oaType: "hybrid", apcUsd: 6420, isInDoaj: false },
    yearlyStats: [
      { year: 2019, worksCount: 980, citedByCount: 121000 },
      { year: 2020, worksCount: 1320, citedByCount: 214000 },
      { year: 2021, worksCount: 1280, citedByCount: 236000 },
      { year: 2022, worksCount: 1190, citedByCount: 205000 },
      { year: 2023, worksCount: 1240, citedByCount: 210000 },
      { year: 2024, worksCount: 1210, citedByCount: 198000 },
    ],
    affiliatedSocieties: [],
  },
};

// Build a (partial) journal record from a homepage JOURNALS entry.
// These deliberately lack CAS / Scopus / trend / OA detail so the
// detail page hides those modules rather than padding them.
function synthJournal(j) {
  const countryByAbbr = {
    "JAMA": ["US", "美国"], "BMJ": ["GB", "英国"],
    "Nat Med": ["GB", "英国"], "Cell": ["US", "美国"],
  };
  const [country, countryName] = countryByAbbr[j.abbr] || ["US", "美国"];
  const publisherByAbbr = {
    "JAMA": "American Medical Association",
    "BMJ": "BMJ Publishing Group",
    "Nat Med": "Nature Portfolio · Springer Nature",
    "Cell": "Cell Press · Elsevier",
  };
  const oa = j.abbr === "BMJ"
    ? { isOa: true, oaType: "gold", apcUsd: 3690, isInDoaj: true }
    : { isOa: false, oaType: "hybrid", apcUsd: null, isInDoaj: false };
  return {
    id: j.id,
    name: j.name,
    abbr: j.abbr,
    cover: j.cover,
    coverStyle: j.coverStyle,
    publisher: publisherByAbbr[j.abbr] || "—",
    issnList: ["XXXX-XXXX"],
    country, countryName,
    foundedYear: j.founded,
    subjectAreas: j.abbr === "Cell" ? ["Cell Biology", "细胞生物学"]
      : j.abbr === "Nat Med" ? ["Medicine, Research & Experimental", "医学研究"]
      : ["General & Internal Medicine", "综合医学"],
    isOpenAccess: oa.isOa,
    homepageUrl: null,          // 🔴 not collected — page hides the primary外链
    metrics: {
      jcr: { impactFactor: j.impact, quartile: "Q1", percentile: null, rank: null, subject: null },
      cas: null,                // 🟡 not exposed — module hidden
      scopus: null,             // 🟡 not exposed — module hidden
      bibliometric: null,
    },
    publicationProfile: { frequency: "每周", medlineIndexed: "Currently-indexed", languages: ["en"], startYear: j.founded },
    openAccess: oa,
    yearlyStats: [],            // 🟡 no trend — chart区不显
    affiliatedSocieties: [],
  };
}

function resolveJournal(id) {
  if (JOURNAL_RICH[id]) return JOURNAL_RICH[id];
  const j = (typeof JOURNALS !== "undefined" ? JOURNALS : []).find(x => x.id === id);
  if (j) return synthJournal(j);
  if (typeof resolveCatalogJournal === "function") {
    const c = resolveCatalogJournal(id);
    if (c) return c;
  }
  return null; // → 404
}

// Map a paper's journal display name → journal id (for cross-link).
const JOURNAL_NAME_TO_ID = {
  "N Engl J Med": "nejm",
  "Lancet": "lancet",
  "JAMA": "jama", "JAMA Neurology": "jama",
  "BMJ": "bmj",
  "Nat Med": "nature-med",
  "Cell": "cell",
};

// ─── Papers ──────────────────────────────────────────────────
// One fully-authored canonical record (rich, RCT, OA). The
// degraded variant is derived from it at render time by the page
// (no abstract / unknown evidence / no MeSH·funding) so the
// switcher can demonstrate field-level fallback on one paper.

const PAPER_RICH = {
  id: "p1",
  title: "Semaglutide 在合并慢性肾病的 2 型糖尿病患者中的长期心血管转归",
  originalTitle: "Long-Term Cardiovascular Outcomes with Semaglutide in Type 2 Diabetes and Chronic Kidney Disease",
  venue: { id: "nejm", name: "N Engl J Med", year: 2026 },
  volumeInfo: "第 394 卷 · 第 7 期 · 612–624 页",
  evidenceLevel: "RCT",
  publicationType: ["Randomized Controlled Trial", "Multicenter Study", "Journal Article"],
  authors: [
    { name: "Perkovic V.", order: 1, isFirst: true, isCorresponding: false, affiliation: "University of Sydney, Sydney, Australia" },
    { name: "Tuttle K. R.", order: 2, isCorresponding: false, affiliation: "University of Washington, Seattle, WA, USA" },
    { name: "Mann J. F. E.", order: 3, isCorresponding: false, affiliation: "KfH Kidney Center, Munich, Germany" },
    { name: "Rossing P.", order: 4, isCorresponding: false, affiliation: "Steno Diabetes Center Copenhagen, Denmark" },
    { name: "Mahaffey K. W.", order: 5, isCorresponding: false, affiliation: "Stanford University, Stanford, CA, USA" },
    { name: "Bakris G. L.", order: 6, isCorresponding: false, affiliation: "University of Chicago, Chicago, IL, USA" },
    { name: "Pratley R. E.", order: 7, isCorresponding: false, affiliation: "AdventHealth Translational Research, Orlando, FL, USA" },
    { name: "Schmieder R. E.", order: 8, isCorresponding: false, affiliation: "University Hospital Erlangen, Germany" },
    { name: "Nangaku M.", order: 9, isCorresponding: false, affiliation: "University of Tokyo, Tokyo, Japan" },
    { name: "Hadjadj S.", order: 10, isCorresponding: false, affiliation: "Nantes Université, Nantes, France" },
    { name: "Idorn T.", order: 11, isCorresponding: false, affiliation: "Novo Nordisk, Søborg, Denmark" },
    { name: "Heerspink H. J. L.", order: 12, isCorresponding: true, affiliation: "University Medical Center Groningen, the Netherlands" },
  ],
  authorCount: 14,
  abstract: {
    type: "structured",
    sections: [
      { label: "BACKGROUND", labelZh: "背景", text: "合并慢性肾病的 2 型糖尿病患者面临较高的心血管事件与肾衰竭风险。GLP-1 受体激动剂在该人群中的长期心血管获益此前证据有限。本试验评估每周一次皮下注射 semaglutide 对主要不良心血管事件的影响。" },
      { label: "METHODS", labelZh: "方法", text: "我们开展了一项多中心、双盲、随机、安慰剂对照的 3 期试验，纳入 eGFR 25–75 mL/min/1.73m² 且伴白蛋白尿的成人患者。受试者按 1:1 随机接受 semaglutide 1.0 mg 或安慰剂。主要终点为首次发生的主要不良心血管事件（心血管死亡、非致死性心梗或非致死性卒中）的复合终点。" },
      { label: "RESULTS", labelZh: "结果", text: "共 3,533 例患者随机分组，中位随访 3.4 年。主要终点事件在 semaglutide 组发生率为 12.1%，安慰剂组为 15.4%（风险比 0.78，95% CI 0.69–0.89，P<0.001）；获益与基线 HbA1c 无关。肾病进展的关键次级终点在 24 个月时即与对照分离。恶心与胃肠道不良反应在治疗组更常见，未见新的安全性信号。" },
      { label: "CONCLUSIONS", labelZh: "结论", text: "在合并慢性肾病的 2 型糖尿病患者中，每周一次 semaglutide 较安慰剂显著降低主要不良心血管事件风险。（由 Novo Nordisk 资助；ClinicalTrials.gov 编号 NCT0XXXXXXX。）" },
    ],
  },
  identifiers: { doi: "10.1056/NEJMoa2603120", pmid: "39812044", pmcid: "PMC12044981", pii: "S0028-4793(26)00312-0" },
  meshHeadings: [
    { term: "Diabetes Mellitus, Type 2", major: true },
    { term: "Renal Insufficiency, Chronic", major: true },
    { term: "Glucagon-Like Peptide-1 Receptor Agonists", major: true },
    { term: "Cardiovascular Diseases", major: false },
    { term: "Albuminuria", major: false },
    { term: "Glomerular Filtration Rate", major: false },
    { term: "Double-Blind Method", major: false },
  ],
  keywords: ["GLP-1", "心血管转归", "慢性肾病", "2型糖尿病"],
  funding: [
    { funder: "Novo Nordisk", grantId: null },
    { funder: "National Institute of Diabetes and Digestive and Kidney Diseases", grantId: "U01-DK0XXXXX" },
  ],
  dates: { received: "2025-11-04", accepted: "2026-01-12", published: "2026-02-19", ePublished: "2026-02-08" },
  numberOfReferences: 42,
  conflictOfInterest: "多位作者报告接受来自 Novo Nordisk、AstraZeneca、Bayer 的研究资助或顾问费；完整声明见原文附录。",
  isOa: true,
  oaUrl: "https://www.nejm.org/doi/full/10.1056/NEJMoa2603120",
  source: "PubMed",
  cites: 142,
  bookmarks: 318,
  readMin: 12,
  aiSummary: "在 eGFR 25–75 区间、伴白蛋白尿的 2 型糖尿病人群中，每周一次 semaglutide 使主要心血管事件下降 22%（HR 0.78，95% CI 0.69–0.89），获益与基线 HbA1c 无关；肾病进展指标在 24 个月时已与对照分离。胃肠道不良反应更常见，未见新的安全性信号。",
};

// Evidence-level ladder. `tier` 1 = strongest. `derived` flags the
// signal as inferred from publicationType + MeSH (not a clean field).
const EVIDENCE_LEVELS = {
  "systematic-review": { tier: 1, labelZh: "系统综述 / Meta", labelEn: "Systematic review", tone: "moss" },
  "RCT":               { tier: 2, labelZh: "随机对照试验", labelEn: "RCT", tone: "moss" },
  "cohort":            { tier: 3, labelZh: "队列研究", labelEn: "Cohort", tone: "amber" },
  "case-control":      { tier: 3, labelZh: "病例对照", labelEn: "Case-control", tone: "amber" },
  "cross-sectional":   { tier: 4, labelZh: "横断面 / 病例系列", labelEn: "Cross-sectional", tone: "slate" },
  "case-report":       { tier: 5, labelZh: "病例报告", labelEn: "Case report", tone: "slate" },
  "unknown":           { tier: 0, labelZh: "证据等级未定", labelEn: "Undetermined", tone: "muted" },
};

// Derive an evidence key from a homepage card's `kind` string.
function deriveEvidence(kind) {
  const k = (kind || "").toLowerCase();
  if (/meta|systematic|综述|review/.test(k)) return "systematic-review";
  if (/rct|randomi|随机/.test(k)) return "RCT";
  if (/cohort|队列|prospective/.test(k)) return "cohort";
  if (/case-control|case control|病例对照|nested/.test(k)) return "case-control";
  if (/case report|病例报告/.test(k)) return "case-report";
  if (/diagnostic|cross|横断/.test(k)) return "cross-sectional";
  if (/model|methods|markov|方法/.test(k)) return "unknown"; // 🔶 can't derive → degraded
  if (/phase 1|i 期|i期|dose/.test(k)) return "cross-sectional";
  return "unknown";
}

// Resolve a paper id → full detail record. Homepage FEED ids are
// hydrated from their card so the detail title matches what was
// clicked; the rich canonical record (p1) carries the full deep
// layer. Other cards reuse p1's deep layer but keep their own
// identity + derived evidence level.
function resolvePaper(id) {
  if (id === "p1") return PAPER_RICH;
  // hydrate from a homepage FEED card if present
  let card = null;
  if (typeof FEED !== "undefined") {
    for (const tab of Object.keys(FEED)) {
      const hit = FEED[tab].find(p => p.id === id);
      if (hit) { card = hit; break; }
    }
  }
  if (!card) return null; // → 404
  const venueId = JOURNAL_NAME_TO_ID[card.journal] || null;
  const evidence = deriveEvidence(card.kind);
  return {
    ...PAPER_RICH,
    id: card.id,
    title: card.title,
    originalTitle: null,
    venue: { id: venueId, name: card.journal, year: card.year },
    evidenceLevel: evidence,
    publicationType: [card.kind || "Journal Article", "Journal Article"],
    identifiers: { ...PAPER_RICH.identifiers, doi: card.doi, pmid: card.pmid, pmcid: card.pmid ? "PMC" + card.pmid : null, pii: null },
    source: card.source,
    cites: card.cites,
    bookmarks: card.bookmarks,
    readMin: card.readMin,
    aiSummary: card.ai,
    isOa: ["PubMed", "Europe PMC"].includes(card.source),
  };
}

// Degraded variant of a paper (for the switcher's 字段降级 state):
// no abstract, evidence undetermined, no MeSH / funding / pmcid.
function degradePaper(p) {
  return {
    ...p,
    originalTitle: null,
    evidenceLevel: "unknown",
    abstract: null,
    meshHeadings: [],
    keywords: [],
    funding: [],
    identifiers: { ...p.identifiers, pmcid: null, pii: null },
    conflictOfInterest: null,
    aiSummary: null,
    isOa: false,
    oaUrl: null,
  };
}

Object.assign(window, {
  JOURNAL_RICH, resolveJournal, synthJournal,
  JOURNAL_NAME_TO_ID,
  PAPER_RICH, resolvePaper, degradePaper,
  EVIDENCE_LEVELS, deriveEvidence,
});
